# Candidate 7.1: corrected disposition after reviewer overturn

*Prepared 2026-07-19 (America/Denver). MICRM Claude (correlated evaluator). Records the evaluator recommendation, the reviewer overturn, and the corrected joint disposition for author ruling. Evaluator, reviewer, and author states are kept separate per protocol. Frozen object: register r12.1 final 666e744e, section 81. Canonical MICRM-v0.2 4180eaef (unchanged). Reviewer response SHA-256 9232c3b1ebb2ca98a5c010ef7163e1b225d02768292014148748cc6f8c11bc49.*

*Chronology-correction note: the reviewer response originally carried date 2026-07-20, which post-dated this evaluator work and the author disposition, both 2026-07-19 (America/Denver). The reviewer identified the date as their own error and authorized its correction to 2026-07-19. The corrected reviewer artifact hashes 9232c3b1; this document cites that corrected artifact. No substantive reviewer content changed; only the date was corrected.*

## State separation

- **Evaluator recommendation (artifact bc80d69b):** Integration-ready core spine refinement. OVERTURNED.
- **Reviewer disposition (artifact 9232c3b1):** Frozen 7.1 Superseded; successor is core operational apparatus, not a new invariant.
- **Author disposition:** pending.

## Why the evaluator recommendation was overturned (conceded)

The evaluator hinge was that v0.2 blocks event-proof (record-action exactness, line 310) but not authorization-transfer, so a decision for proposal P1 could govern the Actuation of a distinct proposal P2, requiring a new negative invariant.

This is wrong on the canonical bytes. Line 464 requires, for Gate governance of an Actuation, independently supported per-event evidence that the Gate evaluated the selected action AND that the outcome is linked to the Actuation record. For distinct P2: there is no per-event Gate evaluation of P2 and no Gate outcome linked to P2's Actuation. Therefore P2's Gate governance fails by the existing burden rule, with no new invariant. The negative confinement the evaluator wanted 7.1 to supply is already produced by v0.2's per-event linkage requirement plus burden.

The evaluator error: reading line 464's linkage clause without carrying its per-event-evidence requirement through to consequence, concluding "forward binding only" when the full clause produces negative confinement as well. This is the same under-reading-the-canonical-text error recorded at candidate 65.8. A correlated evaluator found a gap by assembling less of the canonical mechanism than the decorrelated reviewer did.

## The surviving gap is operational, not a new invariant (accepted)

v0.2 produces the negative *result* by burden. It does not supply the operational apparatus to:

- define what a governance decision was bound to (its binding scope);
- support both exact-action and bounded-set authorization;
- determine whether a transformed action remains within the decision's binding scope;
- record correspondence across proposal, Gate, transformation, and Actuation.

That is core operational apparatus (a definition plus a run-level relational record), not a normative invariant.

## The evaluator's frozen wording overconstrains (conceded, and this is a real defect not just misclassification)

Frozen 7.1's "applies only to the exact proposed transition or action identity" breaks legitimate authorizations that bind a bounded *set* rather than one instance:

- class authorizations (approve all operations of type T under policy P);
- envelope permits (approve transfers within a value/scope envelope);
- batch approvals (approve this set of N actions);
- standing policies (approve all matching actions until revoked);
- reusable capabilities (a capability valid for repeated qualifying invocations).

Under the frozen wording none of these could govern any Actuation, because no single Actuation is "the exact proposed action." The reviewer's repair is accepted: the binding target is "the action instance or member of the bounded action set identified by the decision's binding scope." This preserves exact-action authorization as the singleton case of bounded-set authorization.

## Corrected successor (reviewer-framed, evaluator-endorsed)

**Governance-decision binding scope and proposal-to-Actuation correspondence.** Core operational definition plus run-level relational record. Not a new invariant.

- **Binding scope:** every governance decision has a binding scope, which may be a single action instance or a bounded action set, defined over the consequence-relevant binding dimensions (identifier, root, action type, target, receiving interface, tenant/domain, payload/parameters, quantitative bounds, temporal identity, authority scope, evidence set, policy/configuration, consequence class, composition relations), stated claim-relatively.
- **Correspondence:** an Actuation is governed by a decision only where independently supported evidence establishes the Actuation is the instance, or a member of the bounded set, identified by the decision's binding scope, and (per v0.2 line 464) the Gate outcome is per-event linked to that Actuation.
- **Transformation:** a transformed action remains governed only where independently supported evidence establishes it still falls within the decision's binding scope on every consequence-relevant dimension; otherwise it is a new action requiring its own governance.
- **Record:** run-level relational record linking proposal, decision and its binding scope, Gate event, transformations, and Actuation, referencing layer and seam records without duplicating them.
- The operational findings from the evaluator pass (proposal identity, required dimensions, transformation effect, decision-to-proposal binding, proposal-to-Actuation correspondence, final governance) are retained as the record's findings; only the classification changes from invariant to operational apparatus, and the target broadens from exact-action to binding-scope.

The eleven adversarial cases from the evaluator pass all still resolve correctly under the successor, because bounded-set membership is a superset of exact-identity: cases 1-3 fail as out-of-scope, case 8 passes as in-scope-after-transformation, and the class/envelope/batch cases the frozen wording broke now pass as legitimate bounded-set authorizations.

## Author ruling required

1. Is frozen 7.1 **Superseded**? (Evaluator and reviewer agree: yes.)
2. Is the successor **integration-ready core operational apparatus**, or retained only as **profile/conformance guidance**? (Reviewer leans core operational apparatus; evaluator concurs, because binding scope and correspondence are consumed by cut and exit claims and therefore sit in the operational core, not in a profile.)

```text
candidate closure record:
  candidate identifier: 7.1 proposal-bound governance decision
  exact source state: r12.1 final 666e744e, section 81
  evaluator recommendation: Integration-ready core spine refinement (OVERTURNED)
  reviewer disposition: Superseded; successor is core operational apparatus, not a new invariant
  overturn basis: v0.2 line 464 per-event Gate-evaluation-plus-Actuation-linkage already produces negative confinement by burden; no new invariant needed; evaluator under-read the canonical clause (same error class as 65.8)
  frozen-wording defect: "exact proposed action" overconstrains class/envelope/batch/standing/reusable authorizations; repaired to binding-scope (instance or bounded set)
  successor: Governance-decision binding scope and proposal-to-Actuation correspondence (definition + run-level relational record)
  Larry disposition: pending on (1) Superseded and (2) core-operational vs profile/conformance
  final state: pending author disposition
```

## Rater note

The evaluator recommendation was overturned on the exact point its own rater note flagged for decorrelated review: the 4.2/4.4 hinge, whether authorization-transfer is distinct from event-proof. The note said "if a reviewer shows that v0.2's governance mechanics already confine a decision to its evaluated action, then 7.1 is derivative and my disposition is wrong." The reviewer showed precisely that. The flag was correct and the decorrelated channel resolved it against the evaluator, which is the process working as designed: the correlated evaluator identified its own most-likely-wrong point, and the independent reviewer, holding the full canonical text, closed it. This is worth recording as a clean instance for the development-process writeup, alongside 65.8: two cases where an admission recommendation was corrected to derivative/operational by a reader who assembled more of the fixed canonical artifact than the correlated evaluator did.
