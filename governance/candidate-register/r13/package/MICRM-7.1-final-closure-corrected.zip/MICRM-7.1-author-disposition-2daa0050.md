# Candidate 7.1: author disposition

*Issued 2026-07-19 (America/Denver) by Larry Peseckis. Evaluator, reviewer, and author states are recorded separately; this is the author state. Frozen object: register r12.1 final 666e744e, section 81. Canonical MICRM-v0.2 4180eaef (unchanged). This disposition does not modify the register; integration occurs in a later revision alongside 7.3.*

## Rulings

1. **Frozen Candidate 7.1: Superseded.** Confirmed. The frozen proposition's negative-confinement content is already produced by canonical v0.2 (line 464 per-event Gate-evaluation-and-Actuation-linkage plus burden); its "exact proposed action" wording overconstrains legitimate bounded-set authorizations. It does not enter as a new invariant.

2. **Successor classification: core operational apparatus.** Confirmed (author lean adopted as ruling). "Governance-decision binding scope and proposal-to-Actuation correspondence" is integration-ready core operational apparatus, not profile or conformance guidance.

## What the core-operational ruling settles

Placing the successor in the operational core rather than in profile/conformance means binding scope and proposal-to-Actuation correspondence are available to, and consumed by, cut and exit determinations directly, rather than being deferred to a per-substrate profile. Consequence: a propagation cut or accountability exit that depends on "this Gate decision governs this Actuation" must resolve binding-scope membership and correspondence as core findings, under core burden, not as profile-optional checks. This is the correct placement because the negative result (a decision does not govern an out-of-scope Actuation) is already core-by-burden; the operational apparatus that determines scope membership must sit at the same level as the result it produces.

## Confirmed disposition record

```text
candidate closure record:
  candidate identifier: 7.1 proposal-bound governance decision
  exact source state: r12.1 final 666e744e, section 81
  evaluator recommendation: Integration-ready core spine refinement (OVERTURNED)
  reviewer disposition: Superseded; successor core operational apparatus
  author disposition: (1) frozen 7.1 SUPERSEDED; (2) successor is INTEGRATION-READY CORE OPERATIONAL APPARATUS
  successor: Governance-decision binding scope and proposal-to-Actuation correspondence
    - binding scope: single instance or bounded action set over consequence-relevant dimensions, claim-relative
    - correspondence: Actuation governed only where it is the instance or a bounded-set member identified by the decision's binding scope, with per-event Gate-to-Actuation linkage (v0.2 line 464)
    - transformation: governed only where the transformed action still falls within binding scope on every consequence-relevant dimension
    - record: run-level relational record spanning proposal, decision+scope, Gate, transformations, Actuation
    - findings retained from evaluator pass; classification invariant -> operational apparatus; target exact-action -> binding-scope
  final state: CLOSED at author disposition; integration deferred to the next register revision with 7.3
```

## Sequence

Frozen 7.1 is closed. Per the standing order, Candidate 7.3 (bypass-complete control claim) is the next one-at-a-time pass. Both cluster 7 dispositions integrate into the next register revision together, unless 7.3 exposes a dependency requiring earlier repair.
