# Closure evaluation: Candidate 7.1, proposal-bound governance decision

*Prepared 2026-07-19 (America/Denver). Evaluator: MICRM Claude (correlated rater). Frozen object: register r12.1 final, SHA-256 666e744e9e25795330b72ee3ef037f3884695586d7433bf444d66533fcc1a528, section 81 (proposition) with the binding-record fields therein. Canonical MICRM-v0.2, SHA-256 4180eaefa0369811262b805d189b3c572c8305d107bed6b84dd12c685650b0e2 (citations to that file). Protocol v0.2, SHA-256 5d9e65f8161c3788024ac8869834362a8783f0b5996620627e3ef0e18e1208b2. This pass does not modify the register, does not admit the candidate, and does not treat the register's preliminary "likely spine refinement" note as a result.*

## The frozen object

Section 81 states: a governance decision applies only to the exact proposed transition or action identity to which it was bound; a permit, refusal, or modification detached from one or more required binding dimensions does not govern a later Actuation merely because the two are semantically similar or in the same action class; a transformed proposal requires a new binding determination unless independently supported evidence establishes that the transformation preserved every consequence-relevant binding dimension. The binding record enumerates proposal identifier, proposing principal and root, target and receiving interface, tenant/jurisdiction/domain, consequence-relevant parameters and payload identity, authority source and scope, evidence set, policy and configuration identity, validity conditions and expiration, and final Gate outcome.

## Primary question: derivability test

**Does canonical v0.2 already produce exact proposal binding, or does an explicit negative rule do independent core work?**

The counter-reading, stated at its strongest: v0.2 line 464 already requires, for a qualifying cut, "the Gate evaluated the selected action under its recorded policy and configuration; the final Gate outcome was recorded; and that outcome is linked to the Actuation record." Line 310 already holds that "positive records establish only the event and outcome they record." Line 673 already refuses to let a distribution-level finding establish the outcome of "the specific selected action." So the machinery to say "this permit is about this action and no other" appears present: the Gate evaluates *the selected action*, the outcome links to *the Actuation record*, and a record means only what it records.

**Where the counter-reading holds.** For the case where the Actuation is the very event the Gate evaluated, v0.2 is sufficient. Line 464's "the selected action" and its Actuation linkage already bind the outcome to that one traversal. An identical-action, unchanged-payload permit-then-execute needs no new rule; 7.1 adds nothing there. This must be conceded, and it means 7.1 is not doing work on the trivial case.

**Where the counter-reading fails, and this is the load-bearing finding.** v0.2 line 464 binds the Gate outcome to *the action the Gate evaluated*. It is silent on the case where the executed Actuation is a **different proposal that never reached that Gate**, presented as governed by a decision made about another proposal. Line 464 says the evaluated action's outcome links to *its* Actuation; it does not say that a decision about proposal P1 fails to govern the Actuation of a distinct proposal P2. The linkage is stated positively (the evaluated action binds forward) but not negatively (a non-evaluated action is not bound by another's decision). The gap is precise: v0.2 tells you when a Gate outcome *does* govern its own action; it does not state that a governance decision does *not* travel to a semantically similar but distinct proposal. That negative rule is what 7.1 supplies, and it is not derivable by restating the positive rule, because "P1's outcome governs P1's Actuation" does not entail "P1's outcome does not govern P2's Actuation" without the added premise that proposals are individuated by binding dimensions and that similarity is not identity. That premise is exactly 7.1.

Put in the protocol's required form: **what becomes falsely provable if 7.1 is absent?** A root could assert that a permit issued for proposal P1 governs the Actuation of P2, on the ground that v0.2 nowhere states the permit is confined to P1's identity. v0.2's record-action exactness (line 310) blocks using P1's *record* to prove P2's *event occurred*, but it does not block using P1's *governance decision* to *authorize* P2, because authorization-transfer is a different move than event-proof. The record-action rule is about evidentiary establishment; 7.1 is about governance scope. This is the non-redundancy hinge (see 4.4).

**Answer:** an explicit negative rule performs independent core work, narrowly. v0.2 produces forward binding of an evaluated action to its own Actuation; it does not produce the negative confinement of a governance decision to its bound proposal identity against a distinct similar proposal. 7.1 is that confinement rule.

## Non-overlap table (assigned)

| Rule | Object being bound | Distinct question it answers |
|---|---|---|
| 7.1 Proposal binding | Governance decision to the exact proposed transition/action identity | Is this Actuation the proposal the decision was about? |
| 7.2 Validity continuity | Validity of the decision's conditions from Gate outcome to Actuation | Did the conditions the decision relied on still hold at Actuation? |
| Runtime claim binding | Reviewed-artifact/property claims to runtime identity and participation | Did the artifact that was reviewed actually execute? |
| Record-action exactness | A record of event A cannot establish distinct event B occurred | Does this record prove this event happened? |
| Transformation analysis | Whether a change preserved consequence-relevant properties | Did this change alter a binding-relevant property? |

The four assigned discriminating cases, verified against the table:
- **Same proposal, authority expired:** 7.1 passes (identity matches), 7.2 fails (a condition lapsed). Confirmed distinct.
- **Different proposal, conditions still valid:** 7.1 fails (identity differs), 7.2 cannot repair (validity of the wrong proposal's conditions is irrelevant). Confirmed distinct.
- **Correct proposal, wrong model instance:** 7.1 passes (the proposal is the one decided), Runtime claim binding fails (the executing instance is not the one whose behavior was relied on). Confirmed distinct; 7.1 binds the proposal, not the executor.
- **Byte change, all binding dimensions preserved:** transformation analysis returns preserved, so 7.1's transformed-proposal clause returns "preserved," and 7.1 passes. This is the boundary case (case 8 below).

The table is load-bearing precisely because these four cases dissociate: each rule fails in a situation where the others pass, which is the operational proof that they are not one rule.

## Adversarial pressure tests (eight assigned + three substrate)

**Identity changes.**
1. *$10,000 approved, $100,000 executed.* Quantitative-bound dimension changed. 7.1: proposal identity different, does not govern. Correct, and v0.2 alone would not catch this cleanly, because a $100,000 transfer is the same action *class* and v0.2's Gate-linkage speaks to the evaluated action without stating that amount is an individuating dimension. 7.1 supplies it.
2. *Recipient A approved, B receives.* Target/affected-principal dimension changed. 7.1: different proposal, does not govern. Same finding.
3. *Tenant A approved, identical operation in tenant B.* Tenant/domain dimension changed. 7.1: different proposal. This is the sharpest, because the operation is byte-identical except tenant; only an explicit binding-dimension rule that names tenant catches it. Strong evidence for 7.1's independent work.
4. *Tool/model X approved, router selects Y.* This bifurcates and the bifurcation is instructive: if the governance decision was about the *action* and the model is the *executor*, this is Runtime-claim-binding territory (wrong instance), and 7.1 may pass. If the decision was about *using tool X specifically* (X is a binding dimension of the proposal), then 7.1 fails. The pass must state: whether model identity is a 7.1 dimension is claim-relative (see 5). Correctly routes.

**Transformation cases.**
5. *Payload summarized/rewritten/expanded/parameterized before Actuation.* 7.1's transformed-proposal clause governs: preserved only if every consequence-relevant dimension survived; otherwise new binding determination required. Expansion that changes scope fails; a lossless re-encoding may pass. Correct.
6. *Open-weight planner proposes A; proprietary reviewer changes it to A′; authorization for A is reused.* A′ is a transformed proposal. 7.1: reusing A's authorization requires evidence that A→A′ preserved every binding dimension; a reviewer *changing* the proposal is prima facie a new proposal unless the change is shown binding-neutral. 7.1 does independent work here that no other rule does: this is the mixed open/proprietary case, and 7.1 is what prevents authorization-laundering across the transformation seam.
7. *Proprietary model authorizes a proposal; a different open-weight runtime reconstructs and executes it.* Two failures compose: 7.1 (is the reconstructed proposal the authorized one?) and Runtime claim binding (is the executing instance the one relied on?). 7.1 governs the proposal-identity half; the pass must not let 7.1 absorb the instance-identity half, which is Runtime claim binding's. Correctly separated.

**Boundary case.**
8. *Bytes/wording change, but independently supported evidence establishes every consequence-relevant binding dimension stayed equivalent.* 7.1 returns transformation-effect = preserved, proposal identity = established, governs = yes (subject to 7.2 etc.). This is the case that keeps 7.1 from being a byte-equality rule: it binds *consequence-relevant dimensions*, not bytes, which is the same discipline as the transformation tiers. Without this clause, 7.1 would over-block every compilation and re-encoding; with it, 7.1 blocks only binding-relevant change.

**Non-AI substrates (assigned).**
- *Cloud: approved plan differs from applied plan.* Plan-to-apply drift; 7.1 treats the applied plan as a distinct proposal unless drift is shown binding-neutral. This is the institutionalized everyday form and the strongest non-AI evidence for 7.1.
- *OT: approved command parameters differ from actuator parameters.* Parameter dimension changed; 7.1: different proposal. Safety-critical and substrate-neutral.
- *Institutional: approved contract draft differs from executed instrument.* Document-version dimension; 7.1: the executed instrument is a distinct proposal unless the change is shown binding-neutral. Confirms 7.1 is not AI-specific.

All eleven resolve correctly, and cases 3, 6, and the cloud case are the ones where 7.1 does work no existing rule does.

## Consequence-relevant binding dimensions (assigned definition, tested)

Tested definition: a proposal-binding dimension is result-relevant where changing it can alter the action's identity, authority, permitted scope, receiving semantics, target, affected principal, consequence class, or the applicability of the governance decision. This holds against all eight cases: each failing case is a change in exactly one enumerated dimension (quantity→scope, recipient→target/principal, tenant→domain, tool→identity/applicability, payload→receiving semantics). No case failed on a dimension outside the list, and no listed dimension was inert. The candidate dimension set (identifier, proposing traversal/root, action type, target, receiving interface, tenant/jurisdiction/domain, payload/parameters, quantitative bounds, temporal ordering/expiry, authority source/scope, evidence set, policy/configuration, consequence class, composition relations) is complete against the cases and correctly marked claim-relative: not every field applies to every claim, and applicability must be stated, not assumed. One refinement: "temporal ordering and expiry" overlaps 7.2's validity interval; the pass recommends 7.1 own temporal *identity* (was this proposal the one in the ordered sequence) and 7.2 own temporal *validity* (had it expired), to keep the non-overlap clean.

## Criterion findings

**4.1 Provenance and exact identity:** established. Frozen from r12.1 section 81 at 666e744e.

**4.2 Gap necessity:** established, per the derivability test. What breaks if absent: authorization-transfer from a bound proposal to a distinct similar proposal becomes unblocked at the governance layer (record-action exactness blocks event-proof, not authorization-transfer). Cases 1, 2, 3, 6, and the cloud case demonstrate the gap.

**4.3 Exact-claim sufficiency:** the proposition is clean. One wording note: "does not govern merely because the two are semantically similar or belong to the same action class" is the operative negative; it should be marked a **Normative commitment** under the 8.2 discipline (MICRM chooses to confine governance to bound identity), because it is a chosen allocation, not a structural inevitability. The enumeration of binding-record fields should be marked non-exhaustive and claim-relative.

**4.4 Non-redundancy:** the hinge finding. 7.1 is distinct from record-action exactness (evidentiary establishment vs governance scope), from 7.2 (identity vs validity), from Runtime claim binding (proposal vs executor), and from transformation analysis (7.1 *consumes* the transformation finding to decide identity; it does not duplicate it). Confirmed non-redundant.

**4.5 Scope classification:** core spine refinement (the negative confinement rule), consuming the transformation-analysis finding and the binding-dimension definition; the binding record is run-level relational apparatus (see 4.12).

**4.6 Substrate treatment:** passes strongly; the cloud plan-drift, OT parameter, and institutional instrument cases instantiate without AI-specific wording, and are arguably clearer than the AI cases.

**4.7 Operational findings:** the assigned six-part finding (proposal identity: established/different/unresolved; required dimensions: complete/incomplete/unresolved; transformation effect: preserved/new-proposal/unresolved/n-a; decision-to-proposal binding: established/failed/unresolved; proposal-to-Actuation correspondence: established/excluded/unresolved; final governance: governs/does-not-govern/unresolved) is admission-quality and maps onto every test case. Unresolved-blocks-without-proving-unauthorized is consistent with MICRM's burden discipline.

**4.8 Evidence and dark surfaces:** consistent; the space between a governance decision and a distinct executed proposal is manufactured dark surface if the correspondence is unproven, and under investigative-frame authority the selection of which proposal the decision "was about" is an owned act.

**4.9 Adversarial pressure:** all eleven cases resolve correctly; cases 3, 6, and cloud-drift are where 7.1 does uniquely independent work.

**4.10 Interaction consistency:** consistent with 7.2 (identity vs validity, temporal split noted), Runtime claim binding (proposal vs executor), record-action exactness (governance scope vs event proof), transformation tiers (consumed, not duplicated), and the ratified cluster-3 bonded-root rules (the proposing root is a binding dimension).

**4.11 Scope-authority ownership:** no scope expansion; no new author ruling required beyond disposition. The Normative-commitment marking (4.3) is a labeling directive, not a scope choice.

**4.12 Open questions affected:** answers the register's proposal-binding-record-location construction question. Recommended location, tested and endorsed: a **run-level relational record** linking proposal, governance decision, Gate event, transformations, and Actuation, referencing layer and seam records without duplicating them. This is correct because the binding object spans records (a proposal originates before a seam, may change after it, is evaluated at Gate, becomes real at Actuation); placing it wholly inside Gate, seam, or Actuation records would fragment a spanning relation. Endorsed over the three single-record alternatives.

## Proposed disposition

**Integration-ready core spine refinement.** 7.1 earns the classification against the derivability counter-reading: v0.2 produces forward binding of an evaluated action to its own Actuation but not the negative confinement of a governance decision to its bound proposal identity, and that negative rule is what blocks authorization-transfer to a distinct similar proposal. The proposition is admission-quality with two wording directives (mark the negative clause a Normative commitment; mark the field enumeration non-exhaustive and claim-relative) and one interaction refinement (7.1 owns temporal identity, 7.2 owns temporal validity). The binding record is run-level relational apparatus.

```text
candidate closure record:
  candidate identifier: 7.1 proposal-bound governance decision
  exact source state: r12.1 final, SHA-256 666e744e9e25795330b72ee3ef037f3884695586d7433bf444d66533fcc1a528, section 81
  primary-question finding: v0.2 produces forward binding (evaluated action to its Actuation, line 464) but NOT negative confinement (a decision does not govern a distinct similar proposal); 7.1 supplies the negative rule
  what becomes falsely provable if absent: authorization-transfer from bound proposal P1 to distinct proposal P2 at the governance layer; record-action exactness blocks event-proof, not authorization-transfer
  non-redundancy: distinct from record-action exactness (evidentiary vs governance scope), 7.2 (identity vs validity), Runtime claim binding (proposal vs executor), transformation analysis (consumed, not duplicated)
  adversarial result: 11 of 11 cases resolve correctly; cases 3 (tenant), 6 (open/proprietary transform), and cloud plan-drift show uniquely independent work
  binding-dimension definition: tested complete against all cases; claim-relative applicability confirmed
  record location: run-level relational record spanning proposal/decision/Gate/transformation/Actuation, referencing not duplicating layer and seam records
  wording directives: mark the negative clause a Normative commitment (8.2); mark field enumeration non-exhaustive and claim-relative
  interaction refinement: 7.1 owns temporal identity; 7.2 owns temporal validity
  reviewer disposition: Integration-ready core spine refinement
  Larry disposition: pending
  final state: pending reviewer and author disposition
```

## Rater note

Correlation flag, and it is specific. This pass concludes admission, and admission recommendations from inside the distribution carry more risk than supersessions. The place a decorrelated reviewer should push hardest is the 4.2/4.4 hinge: my whole case rests on the claim that "authorization-transfer" is a distinct move from "event-proof," and therefore that record-action exactness (which blocks the latter) leaves the former unblocked. If that distinction collapses, if a reviewer shows that v0.2's governance mechanics already confine a decision to its evaluated action such that P1's permit structurally cannot authorize P2, then 7.1 is derivative, not core, and my disposition is wrong. I believe the distinction holds because line 464 binds *forward* (evaluated action to its Actuation) without binding *negatively* (non-evaluated action not governed by another's decision), and those are not the same proposition. But that is exactly the kind of load-bearing scope claim a reader who did not write this evaluation should check directly against lines 310 and 464 of the canonical text, because it is the single point on which the entire disposition turns.
