# Reviewer response: Candidate 7.1, proposal-bound governance decision

*Prepared 2026-07-19 (America/Denver). Reviewer: OpenAI GPT-5.6 Thinking, decorrelated reviewer. Evaluated artifact: `MICRM-7.1-proposal-binding-closure-evaluation-bc80d69b.md`, SHA-256 `bc80d69b4aa3d976eef53a9803e6894b45f103f22cd307944a33bd33d76ed7e2`. Frozen candidate source: register r12.1 final, SHA-256 `666e744e9e25795330b72ee3ef037f3884695586d7433bf444d66533fcc1a528`, Section 81 and Section 85.1. Canonical base: MICRM-v0.2, SHA-256 `4180eaefa0369811262b805d189b3c572c8305d107bed6b84dd12c685650b0e2`. This response is reviewer input only. It does not modify the register, admit a candidate, or change canonical MICRM-v0.2.*

## Package and exact-byte verification

The returned evaluator package is intact.

```text
outer transport wrapper:
  836aa2a90016221855f903613a1724b7179dec6d0fe8436cceda039c354a6c10

inner package:
  f9947e1358d876d75cae5129c37fcaebe1d6b4e68733eac55eb1919ec5e2a93a

evaluation:
  bc80d69b4aa3d976eef53a9803e6894b45f103f22cd307944a33bd33d76ed7e2

verification record:
  53e9c012ab6eed95f6a9f1ba11f01d069abc57fa6ea5cde519ffa59e55a805d4

manifest:
  0b5076485f6db01bfb5559fee977ab87030b2054f05a557a2066bc6abc096324

detached receipt:
  6fe6ebcb7c5a7dacbe028df53abe7290d659ca05b6b6f19f424da1116253b313
```

The inner archive has three entries, the manifest lists two files and excludes itself, `sha256sum -c` passes two of two, and the loose evaluation, verification record, and manifest are byte-identical to the copies in the inner package. The first production use of `build-package-v2.sh` therefore passes.

## Review result

The evaluation is disciplined, concedes the trivial case correctly, separates 7.1 from 7.2 and Runtime claim binding, and locates the surviving record at the correct run-level relation. Its proposed disposition does not survive review, however.

The load-bearing derivability finding fails for two independent reasons:

1. canonical v0.2 already prevents a decision for P1 from establishing Gate governance for distinct Actuation P2 by its per-event identity, selected-action, and Actuation-linkage burden; and
2. the frozen 7.1 wording is too narrow because it assumes an exact proposal instance where a governance decision may intentionally bind a bounded class, envelope, batch, capability, or standing authorization.

The surviving material is not a new core negative rule. It is an operational identity-and-correspondence apparatus needed to apply the existing canonical rule consistently.

## 1. The derivability hinge does not hold

The evaluator distinguishes:

- event proof, governed by record-action exactness; and
- authorization transfer, which it says v0.2 leaves unblocked.

The conceptual distinction is real. The claimed canonical gap is not.

Canonical v0.2 does not permit a P1 record to establish governance for P2 merely because governance scope is a different claim type. The governance claim itself remains subject to exact per-event evidence and linkage.

The relevant canonical mechanics are cumulative:

1. **Gate is action-specific by position.** Section 5 states that Gate is the final control stage acting on the selected action after Action Selection and before Actuation. It is not a free-standing authorization object that can be attached later to a different action.

2. **Positive permit evidence is event-specific.** Section 6.1 states that a positive permit or no-change record is evaluated according to its own event identity, custody, independence, and linkage.

3. **A control-permission exit requires the selected event.** Section 6.1 requires positive per-event outcome evidence where an exit depends on a control having evaluated and permitted a specific non-intervened event.

4. **The qualifying-cut condition requires exact correspondence.** Section 9.3 condition 6 requires independently supported evidence that the Gate evaluated the selected action and that the final Gate outcome is linked to the Actuation record.

5. **The authoritative seam record already carries correspondence fields.** Section 11 includes selected-action class membership, Gate evaluation event identity, per-event Gate outcome evidence, final Gate outcome, and Actuation identity.

Under those rules, a permit for P1 cannot establish Gate governance for P2. To use P1's permit for P2, the root would have to establish that P2 was the selected action evaluated at the Gate and that P1's outcome was linked to P2's Actuation. Where P1 and P2 are different, that showing fails. Where their identity relation is unresolved, the claimed governance, cut, or exit fails by burden.

The canonical result therefore already contains the negative consequence:

```text
No per-event evidence that the Gate evaluated P2
or no established P1-to-P2 identity and Actuation linkage
    ->
Gate governance for P2 unestablished
    ->
dependent cut or exit unavailable
```

Canonical v0.2 expresses this as a positive burden rather than a separate prohibition, but that drafting form does not leave authorization transfer available. A claim that P1 governed P2 is exactly the claim that must satisfy the selected-action and linkage conditions. It cannot avoid those conditions by being labeled authorization rather than event proof.

### Correction to the evaluator's strongest claim

The evaluation says:

> record-action exactness blocks event-proof, not authorization-transfer.

That statement is incomplete because it isolates line 310 from Sections 5, 6.1, 9.3, and 11. Line 310 alone does not settle governance scope. The combined canonical machinery does.

The correct finding is:

> Record-action exactness is not by itself a complete proposal-binding rule, but canonical Gate identity, per-event permit evidence, selected-action evaluation, and Actuation linkage already prevent a distinct proposal's decision from establishing governance for the selected Actuation.

The evaluator's admission case therefore does not pass criterion 4.2 or 4.4 as stated.

## 2. The adversarial cases show an identity-resolution need, not a new accountability rule

The amount, recipient, tenant, transformed-plan, and cloud-drift cases do not produce a false canonical result in v0.2.

For each case, the actual question is whether the Gate-evaluated selected action is the Actuation that became operationally real. If amount, recipient, tenant, payload, or plan version changes in a result-relevant way, correspondence is failed or unresolved. Condition 6 cannot be established.

The evaluator is correct that v0.2 does not provide one consolidated proposal-identity test or one run-level proposal-binding record. That is the surviving gap.

The cases establish the need to operationalize:

- what the governance decision was bound to;
- which dimensions distinguish covered from non-covered actions;
- whether a transformed action remains inside that binding scope;
- and whether the Gate-evaluated object corresponds to the Actuation.

They do not establish the need for a second normative rule saying a decision for one action cannot govern another. The canonical burden already produces that result.

## 3. The frozen proposition overconstrains bounded authorizations

The evaluator did not test the strongest counterexample to the phrase:

> A governance decision applies only to the exact proposed transition or action identity to which it was bound.

A governance decision may intentionally bind:

- a bounded action class;
- a parameter envelope;
- a batch or transaction set;
- a capability with explicit target and quantitative limits;
- a standing policy evaluated per event;
- a quorum-approved operating domain;
- or a reusable authorization whose membership predicate is independently established.

Examples:

```text
Permit transfers up to $10,000 to recipients in approved set R
during interval T under policy version V.

Permit deployment of any artifact whose digest appears in signed set S
to tenant A through interface I.

Permit actuator commands within envelope E
while safety interlock state Q remains valid.
```

In those cases, a later action need not be byte-identical to one previously proposed. The required finding is that the Actuation is a member of the action instance or bounded action set identified by the decision's binding scope.

The frozen wording can be repaired by interpreting "action identity" broadly enough to include a bounded set, but its explicit rejection of same-action-class reasoning makes that interpretation unstable. Same class alone is insufficient, but established membership in an explicitly authorized bounded class can be sufficient. The text must say both.

This is an exact-claim defect under criterion 4.3. It prevents the frozen proposition from being integration-ready as written.

## 4. "Consequence-relevant" is not the exact binding qualifier

The transformed-proposal clause uses:

> every consequence-relevant binding dimension

The relevant dimensions are those required by the governance decision's evidenced binding scope and the selected MICRM claim. A dimension may matter to authority, jurisdiction, contractual permission, identity, or policy applicability even where it does not change the physical or business consequence class.

A better term is:

> required binding dimension

or:

> result-relevant binding dimension for the selected governance claim

The record must distinguish:

- consequence-relevant dimensions;
- authority- or policy-relevant dimensions;
- identity and membership dimensions;
- and applicability conditions.

Using only "consequence-relevant" risks allowing a transformation that preserves the apparent consequence while violating the authorization object.

## 5. Surviving architectural result

The evaluation correctly identifies three pieces worth retaining:

1. **A binding-scope definition**
2. **A proposal-to-Actuation correspondence finding**
3. **A run-level relational record**

These are operational apparatus for canonical Gate and evidence mechanics.

### Proposed repaired wording

> **Governance-decision binding scope and proposal-to-Actuation correspondence:** A governance decision governs an Actuation only where independently supported evidence establishes that the Actuation is the action instance, or a member of the bounded action set, identified by the decision's binding scope.
>
> The binding scope identifies every required dimension needed to distinguish covered from non-covered actions for the selected governance claim at the incident resolution. Applicable dimensions may include action or transition identity, action class or membership predicate, proposing traversal and root, target, receiving interface, tenant, jurisdiction, operating domain, payload, parameters, quantitative bounds, temporal identity, authority source and scope, evidence or state references, policy and configuration, composition conditions, and permitted transformations.
>
> Semantic similarity, common outcome, shared action class, or a matching product or operation label does not by itself establish membership in the binding scope. Byte or form difference does not by itself establish non-membership.
>
> Where the proposal or selected action was transformed, correspondence is established only where independently supported evidence establishes that the transformed action remains inside the decision's binding scope, or a new governance evaluation binds the transformed action.
>
> If correspondence fails, the prior decision does not govern the Actuation. If correspondence is unresolved, governance and every dependent cut or accountability exit remain unestablished. Failure or unresolvedness does not by itself prove unauthorized action, factual contribution, negligence, or liability.

This wording handles both instance-specific and class-bound governance without creating an exemption for semantic similarity.

### Recommended findings

```text
governance-decision binding and correspondence record:
  governance decision identifier:
  decision type:
    instance-specific / bounded-set / standing-policy / other

  binding scope:
    action or transition identifier, if instance-specific:
    action-set or membership predicate, if set-bound:
    proposing traversal and root:
    target and receiving interface:
    tenant, jurisdiction, or operating domain:
    payload, parameter, and quantitative bounds:
    temporal identity and ordering:
    authority source and scope:
    evaluated evidence or state references:
    policy and configuration:
    permitted transformation predicates:
    composition requirements:
    non-applicable fields and support:

  Gate:
    Gate evaluation event:
    evaluated action identity:
    final outcome:

  transformation:
    lineage:
    required binding predicates preserved / failed / unresolved:

  Actuation:
    Actuation identity:
    binding-scope membership
      (established / failed / unresolved):
    Gate-to-Actuation correspondence
      (established / failed / unresolved):

  dependent 7.2 validity-continuity record:
  evidence sources:
  independent corroboration:
  custody and modification control:
  residual dark surface:
```

The record belongs at run level and should reference the Action Selection, Gate, transformation, seam, and Actuation records. The evaluator's placement finding is accepted.

## 6. Criterion findings

```text
4.1 Provenance and exact identity:
  PASS

4.2 Gap necessity:
  FAIL for a new negative core rule
  PASS for identity-and-correspondence operational apparatus

4.3 Exact-claim sufficiency:
  FAIL as frozen
  exact-instance wording does not cover bounded-set governance
  "consequence-relevant" is too narrow

4.4 Non-redundancy:
  FAIL for the proposed normative confinement rule
  PASS for the consolidated identity, membership, transformation,
  and Actuation-correspondence procedure

4.5 Scope classification:
  core operational definition and run-level record
  not a new invariant or independent accountability rule

4.6 Substrate treatment:
  PASS after bounded-authorization repair

4.7 Operational findings:
  PASS with repaired membership and correspondence findings

4.8 Evidence and dark surfaces:
  PASS

4.9 Adversarial pressure:
  PARTIAL
  assigned cases pass
  bounded-class, envelope, batch, standing-policy, and reusable-capability
  cases were missing and expose an overconstraint

4.10 Interaction consistency:
  PASS after repair
  7.1 apparatus resolves identity and membership
  7.2 resolves continuing validity
  Runtime claim binding resolves runtime artifact and property claims

4.11 Scope-authority ownership:
  no new author scope ruling required

4.12 Open questions:
  record location resolved as run-level relational apparatus
```

## Reviewer disposition

**Frozen Candidate 7.1 is not integration-ready as a core spine refinement.**

Recommended disposition:

> **Superseded by governance-decision binding scope and proposal-to-Actuation correspondence, classified as core operational apparatus rather than a new normative invariant.**

The frozen candidate's negative rule is derivative of canonical v0.2's per-event selected-action and Actuation-linkage burden. Its exact-instance formulation is also too narrow for legitimate bounded-set governance. The successor preserves the real gap: explicit action-identity or membership resolution, transformed-action correspondence, and a run-level record.

```text
candidate closure record:
  candidate identifier:
    7.1 proposal-bound governance decision

  exact source state:
    r12.1 final
    SHA-256 666e744e9e25795330b72ee3ef037f3884695586d7433bf444d66533fcc1a528
    Sections 81 and 85.1

  evaluator artifact:
    bc80d69b4aa3d976eef53a9803e6894b45f103f22cd307944a33bd33d76ed7e2

  canonical-gap finding:
    no new negative-confinement rule is required
    canonical v0.2 already requires per-event selected-action evaluation
    and Gate-outcome-to-Actuation linkage

  surviving gap:
    no consolidated procedure defines the decision's binding scope,
    resolves instance or bounded-set membership,
    evaluates transformed-action correspondence,
    and records the relation across proposal, Gate, and Actuation

  exact-claim defect:
    frozen "exact proposal" wording overconstrains bounded class,
    envelope, batch, standing-policy, and reusable-capability governance

  reviewer disposition:
    Superseded

  successor:
    governance-decision binding scope and proposal-to-Actuation correspondence

  successor classification:
    core operational definition and run-level relational record
    not a new invariant

  Larry disposition:
    pending

  final state:
    pending author disposition
```

## Rater note

The evaluator correctly identified the place to attack, but framed the canonical comparison too narrowly around lines 310 and 464. The decisive unit is the combined canonical mechanism: Gate position, event-specific permit evidence, the specific-event burden, selected-action evaluation, Actuation linkage, and the Section 11 correspondence fields.

The author should decide two separate matters explicitly:

1. whether frozen 7.1 is superseded rather than integration-ready; and
2. whether the repaired successor is accepted as integration-ready operational apparatus or merely retained as profile/conformance guidance.

No register bytes should change before that author disposition.
