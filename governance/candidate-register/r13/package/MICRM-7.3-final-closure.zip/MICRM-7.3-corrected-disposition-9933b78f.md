# Candidate 7.3: corrected disposition after reviewer correction

*Prepared 2026-07-20 (America/Denver). MICRM Claude (correlated evaluator). Records the evaluator disposition (classification survived), the reviewer's correction of the evaluator's rationale (did not survive), and the corrected joint disposition for author ruling. Evaluator, reviewer, and author states are kept separate per protocol. Frozen object: register r12.1 final 666e744e, sections 83-86. Canonical MICRM-v0.2 4180eaef (unchanged). Reviewer response SHA-256 022c94d000e0ba0ebc19096de518c1cea9593b1a2a718b1eb5e496d3669d3992.*

## State separation

- **Evaluator classification (artifact e9229b2e):** Frozen 7.3 = Conformance or assurance claim with record. **SURVIVES.**
- **Evaluator rationale (artifact e9229b2e):** "non-bypassability and per-path accountability quantify over the same capable-path set, therefore cannot diverge." **OVERTURNED.**
- **Evaluator successor classification:** core operational apparatus for the conformance layer. **NARROWED** by reviewer to conformance/assurance apparatus, not core operational.
- **Reviewer disposition (artifact 022c94d0):** classification confirmed; rationale corrected; successor narrowed; control-set split to a separate candidate.
- **Author disposition:** pending.

## The rationale that was overturned, and why it was wrong (conceded)

The evaluator argued that frozen 7.3 is derivative at the accountability level because non-bypassability and canonical per-path exit "quantify over the same evidence-compatible capable-path set." That is wrong on the canonical bytes.

Canonical line 55 binds "every bonded root with an **ancestor traversal path** to that consequence" and requires cuts "on every path **from that root to the selected consequence**." That set is the **incident run graph**: the paths that actually or possibly carried the selected consequence in this incident. Candidate 7.3 quantifies over a **different set**: "every evidence-compatible path **capable** of producing the relevant Actuation," which is the bounded **architectural** set of routes that *could* reach the Actuation, used or not.

These sets are not identical. The reviewer's decisive counterexample:

```text
A capable bypass route is independently established as UNUSED in the incident.
  Named-control non-bypassability:  FAILED (a capable path avoids the control)
  Actual bypass use:                EXCLUDED
  Incident ancestor path via bypass: ABSENT (the route was not an ancestor path)
  Incident root exit:               MAY STILL SUCCEED on the actual paths,
                                    subject to all other canonical conditions
```

The non-bypassability finding (FAILED) and the incident accountability finding (exit may succeed) diverge on exactly this case. My claim that they cannot diverge is disproved. The error: I treated canonical per-path exit as ranging over architecturally-capable paths when it ranges over incident-ancestor paths. This is the same error class as 7.1 and 65.8, misreading the scope of a canonical quantifier, but with the opposite sign: on 7.1 I under-read a clause and called derivative content core; here I over-read a quantifier's scope and called divergent content identical.

**The classification still survives** because it never depended on the identity-of-quantification claim: frozen 7.3 remains a conformance/assurance claim (a positive statement that a named control is the mandatory chokepoint), not an accountability invariant. But the *reason* it survives is now the correct one: not "the accountability result already covers it," but "the accountability result and the non-bypassability result are different claims over different path sets, and the non-bypassability claim is the conformance one." The reviewer's correction makes the disposition *more* defensible, because it removes a false premise and replaces it with the actual distinction.

## Case 2(b) correction (conceded)

The evaluator wrote that a privileged route available but proven unused "would still block accountability exit because bypass capacity is present (line 335)." Too broad, and wrong for the same reason.

Canonical dark-surface capacity (line 335, "it can block exit when its relevant capacity is present or unresolved") is **incident-relative and claim-relative**. It bounds uncertainty about *this incident's* relevant occurrences and paths. It is not a global rule that every unused capable interface anywhere in the architecture blocks every root exit. Reading it that way would make MICRM silently require bypass-free architecture as a precondition of incident accountability, which canonical v0.2 does not do and which contradicts the whole apportionment-to-overlays stance.

Corrected case 2(b): a privileged route available but independently established as unused **defeats the positive assurance claim** that the named control is non-bypassable; it does **not** automatically become an ancestor path in the incident, and it does not by itself block the incident root exit. Actual bypass use is excluded; the incident exit stands or falls on the actual ancestor paths under canonical conditions.

## Successor classification, narrowed (conceded)

The evaluator classified the bypass-surface record and equivalence test as "core operational apparatus for the conformance layer." The reviewer narrows this to **integration-ready conformance/assurance apparatus, not MICRM core operational apparatus**, and the narrowing is correct on the following distinction:

- The 7.1 successor is core operational because proposal-to-Actuation correspondence is **directly consumed by** Gate governance, propagation cuts, and accountability exits. It is machinery the accountability core reaches for.
- The 7.3 apparatus supports a **distinct positive assurance claim** (named-control non-bypassability). Canonical accountability can fully resolve *without* proving that a named control is universally non-bypassable. The apparatus is therefore not consumed by the accountability core; it serves a conformance/assurance claim that sits beside the core.

This directly answers the evaluator's own rater-note second question ("whether the successor is under-classified... if bypass-completeness is consumed by a propagation cut it would be core operational"). The reviewer's answer: it is not consumed by a cut, because the cut operates on incident-ancestor paths and needs no named-control chokepoint notion. So the successor is conformance apparatus, not core operational.

## Control-set extension, split to a separate candidate (accepted)

Frozen 7.3 correctly evaluates one named control. A distributed architecture where Control A and Control B are each individually bypassable but the set {A, B} is bypass-complete is a **separate conformance object**, not a repair to be folded into the singular frozen proposition. The reviewer names it:

- **Bypass-complete enforcement set** (separate developed conformance candidate): requires explicit member qualification, path-coverage, coverage-union, and unresolved-path findings. This is the coverage-of-set shape from cluster-6 65.7/65.9, now at the control-set level. It should be developed as its own candidate, not silently merged.

## Author ruling required

```text
candidate closure record:
  candidate identifier: 7.3 bypass-complete control claim
  exact source state: r12.1 final 666e744e, sections 83-86
  evaluator classification: Conformance or assurance claim with record (SURVIVES)
  evaluator rationale: same-path-set-therefore-no-divergence (OVERTURNED)
  correction: canonical per-path exit ranges over INCIDENT-ANCESTOR paths; 7.3 ranges over ARCHITECTURALLY-CAPABLE paths; a proven-unused capable bypass fails non-bypassability while the incident exit may still succeed; the two findings diverge
  case 2(b): corrected; unused capable route defeats the assurance claim but is not automatically an incident ancestor path and does not by itself block exit; dark-surface capacity is incident- and claim-relative, not global
  frozen disposition: Conformance or assurance claim with record
  successor: Bypass-surface record + eight-dimension accountability-equivalent-control test = INTEGRATION-READY CONFORMANCE/ASSURANCE APPARATUS (NOT core operational; reviewer-narrowed)
  separate candidate: Bypass-complete enforcement set (control-set coverage; member qualification, coverage-union, unresolved-path findings)
  equivalence definition: eight dimensions, claim-relative, no label-based equivalence (unchanged, survives)
  population coverage: not imported; incident-level (unchanged)
  Larry disposition: pending on (1) frozen 7.3 conformance classification; (2) successor as conformance/assurance apparatus; (3) whether to open the Bypass-complete enforcement set candidate now or defer
  final state: pending author disposition
```

## Rater note

The reviewer overturned the evaluator's rationale on the exact point the evaluator's own rater note flagged: "whether there is any consequence for which a control can be non-bypassable in the conformance sense while the per-path accountability result diverges... that identity of quantification is the load-bearing claim." The note said an independent reader should verify it against lines 55 and 335. The reader did, found the quantifiers range over different sets, and produced the counterexample. This is now the fourth consecutive instance (65.8, build-tool, 7.1, 7.3) where the correlated evaluator's most-load-bearing claim was flagged by its own rater note and then overturned by the decorrelated channel. The pattern is stable enough to state as a property: the evaluator can reliably *locate* its most-likely-wrong claim but cannot reliably *resolve* it, because resolving it requires the ground the evaluator lacks. The flag is worth generating precisely because the independent channel then knows where to cut. That is the intended division of labor, working.
