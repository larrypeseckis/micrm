# Closure evaluation: Candidate 7.3, bypass-complete control claim

*Prepared 2026-07-20 (America/Denver). Evaluator: MICRM Claude (correlated rater). Frozen object: register r12.1 final, SHA-256 666e744e9e25795330b72ee3ef037f3884695586d7433bf444d66533fcc1a528, sections 83-86. Canonical MICRM-v0.2, SHA-256 4180eaefa0369811262b805d189b3c572c8305d107bed6b84dd12c685650b0e2 (citations to that file by line). Protocol v0.2, SHA-256 5d9e65f8161c3788024ac8869834362a8783f0b5996620627e3ef0e18e1208b2. This pass does not modify the register, admit the candidate, or treat the section-84 preliminary "largely a synthesis" note as the disposition.*

## Method under the 7.1 warning

The immediately prior candidate (7.1) was recommended core by this evaluator and overturned to derivative-plus-operational by the decorrelated reviewer, because the evaluator under-read the canonical text and treated a result already produced by burden as needing a new invariant. This pass runs the 7.3 derivability test against that failure: the default hypothesis is that the accountability result is already canonical, and 7.3 must earn any core classification by showing a result that becomes falsely provable, unaccountable, or unresolved in its absence. I will try to derive 7.3 away first, and admit core only if derivation fails.

## Primary question: derivability test

**Does canonical v0.2 already produce the accountability result through per-path evaluation, qualifying cuts, structural exclusion, and dark-surface capacity exclusion?**

The frozen proposition (line 3035): a control is non-bypassable only where every evidence-compatible path capable of producing the Actuation must pass through the control or an accountability-equivalent control; a documented primary path does not establish non-bypassability; an unresolved bypass path blocks the claim by burden.

Map each clause to canonical v0.2:

- "Every evidence-compatible path capable of producing the Actuation" is the candidate-path set of line 55 ("on every path from that root to the selected consequence"). Canonical.
- "Must pass through the control" is the requirement that each path contain a qualifying propagation cut or structural exclusion (line 55, line 73). A control that every path must cross is the mechanism by which every path acquires its cut. Canonical.
- "A documented primary path does not establish non-bypassability" is a direct restatement of line 55's "every path," which already refuses exit on the strength of one path. Canonical.
- "An unresolved bypass path blocks the claim by burden without proving the bypass was used" is line 55's "an unresolved path prevents exit" plus line 335's dark-surface rule (present or unresolved capacity blocks exit) plus the standing "blocks without proving contribution." Canonical, verbatim in substance.

**The finding: the accountability result of 7.3 is fully produced by canonical v0.2.** Ask the protocol's required question, what becomes falsely provable if 7.3 is absent? Nothing at the accountability level. If a root asserts exit while an unresolved administrative bypass path exists, canonical line 55 already denies the exit: the bypass is an unresolved path, and an unresolved path prevents exit. If the bypass path has established capacity to reach the Actuation, line 335 denies exit on capacity-present grounds. If the bypass is structurally incapable, line 73 structural exclusion already removes it from the candidate set. In none of these does the absence of 7.3 let a root falsely exit, falsely establish a cut, or escape accountability. The per-path exit rule already *is* bypass-completeness applied to accountability: a root exits only if every path is cut, which is exactly "no uncut path bypasses the enforcement."

**Therefore frozen 7.3 is not independent core architecture at the accountability level.** This is the same shape as the 7.1 overturn, reached this time by the evaluator directly rather than by the reviewer: a candidate that names an important property but whose accountability content is already produced by the per-path-plus-dark-surface machinery.

**What 7.3 does add, and it is not nothing.** There is a claim v0.2 does not produce: the *conformance/assurance* claim that a *named control* is non-bypassable for a consequence, as a positive statement about a control's enforcement completeness, distinct from the accountability statement about a root's exit. v0.2 answers "did this root exit" (per-path cuts). 7.3's distinctive object is "is this named control the mandatory chokepoint for this consequence," which is a claim a deployer makes about their architecture, an assurance property, not an accountability finding. The section-84 note reaches the same place ("may become a worked conformance test... should not be admitted as an additional invariant unless... independent necessity"). The bypass-surface record (85.3) is the apparatus for that assurance claim: it reuses canonical path, capacity, and dark-surface findings and organizes them around a named control.

**Answer:** the accountability result is canonical and already produced. Frozen 7.3 does not perform independent core architectural work. Its distinctive content is a conformance/assurance claim about a named control's enforcement completeness, supported by a run-level bypass-surface record that reuses canonical findings. The register's tested hypothesis (line 321) is correct.

## Required finding separations (assigned; kept distinct)

| Finding | Question | Canonical home |
|---|---|---|
| Actual bypass use | Did the Actuation travel an alternate path? | Not required for the claim; an event fact |
| Bypass capacity | Could an alternate path produce the Actuation/class? | Dark-surface capacity (line 335) |
| Control non-bypassability | Must every capable path cross this control/equivalent? | 7.3's distinctive conformance object |
| Qualifying cut | Did one path satisfy every cut condition? | Line 55 / cut conditions |
| Root exit | Did every path from the root contain a cut/exclusion? | Line 55 |
| Dark-surface exclusion | Can the bounded unobserved surface carry the capacity? | Line 335 |
| Population coverage | How often did the control evaluate qualifying events? | Deferred from v0.2; NOT imported |

The three-way separation the assignment demands holds: "a bypass path exists" (bypass capacity present or unresolved) defeats a *universal control claim* without establishing "the bypass was used" (actual bypass use, an event fact that 7.3 explicitly does not prove) and is distinct from "the asserted control is not non-bypassable" (the conformance finding). 7.3 correctly couples the first to the third by burden and severs both from the second. Population coverage is explicitly not imported: every finding below is incident-level, no denominator, no false-negative rate, no deployment-wide assurance.

## Accountability-equivalent control (assigned definition, tested)

Tested minimum definition: a control is accountability-equivalent for a selected non-bypassability claim only where independently supported evidence establishes that, on the alternate path, it carries equivalent authority-bearing responsibility, protective scope, real refusal/modification capacity, proposal-binding treatment, validity continuity, Actuation reach, evidence burden, and accountability termination for the selected consequence. Equivalence is not implementation identity; no equivalence arises from product label, declared purpose, common vendor, or affiliation alone.

Tested against the cases below, this holds. The eight dimensions are each load-bearing: dropping any one admits a false equivalence (e.g., a control with equal refusal capacity but no accountability termination is not equivalent, case 7; a control with equal authority but no Actuation reach cannot enforce, case 11-B). The definition is claim-relative and correctly refuses label-based equivalence, consistent with the ratified 65.5 guard and the cluster-3 anti-laundering discipline (proximity/affiliation is not identity). Finding values established/failed/unresolved/not-applicable are correct; "not applicable" is needed for single-control claims where no alternate path invokes equivalence.

## Twelve adversarial cases

1. **Correct refusal, direct actuator bypass.** Canonical Gate-to-Actuation linkage (line 464 / 86.1) already resolves the accountability result: the refusal record establishes a decision occurred, not that Actuation was controlled; the direct path is uncut, so exit fails. 7.3 adds only the distinct conformance claim that the policy service was bypassable. Confirms the derivability finding.

2. **Clean primary path, privileged route.** Three variants: (a) route used, direct accountability failure by uncut path; (b) route available but shown unused, the accountability exit still fails because bypass *capacity* is present even if unused (line 335), while actual-use is excluded, and the conformance claim "non-bypassable" fails because a capable uncut path exists; (c) use unresolved, exit fails by burden, conformance claim unresolved. All three resolve on canonical machinery; 7.3 supplies the conformance vocabulary. The variant (b) split, capacity-present-but-use-excluded still defeating the control claim, is the sharpest demonstration that non-bypassability is about capacity not use.

3. **Emergency override through separate authorization.** Not automatic failure, not automatic equivalence. The emergency route defeats the claim about the *named* control; it satisfies a broader claim only if the emergency authorization is established as an accountability-equivalent control on all eight dimensions; otherwise unresolved. Correctly routes to the equivalence test rather than a reflex.

4. **Retry/fallback.** Four sub-cases: same control (claim holds), different control (equivalence test), advisory-only control (fails, an advisory control has no real refusal capacity, dimension 3), no control (fails, uncut path). Each resolves on per-path plus equivalence; the advisory-only case ties to the 86.x advisory findings.

5. **Cached/stale authorization.** The assignment's own separation is correct and I confirm it: if the path *crossed* the required control but the grant was stale, 7.3 (bypass) may pass and 7.2 (validity) fails, distinct findings; if the path *avoided* the control, 7.3 fails or is unresolved even if the alternate grant was current. This is the clean dissociation of 7.3 from 7.2: 7.3 is about *which path*, 7.2 is about *whether the crossing was still valid*. They fail independently.

6. **Shadow/legacy workflow.** Evidence that the legacy route is disabled must be classified: configuration assertion alone is insufficient (it is a claim, not structural evidence); path absence requires evidence the route cannot be invoked; structural exclusion requires the route be incapable of the consequence class; dark-surface capacity exclusion requires the bounded unobserved surface be shown incapable. Only the last three support the claim; mere "we turned it off" is configuration assertion and leaves the path unresolved. This is the case where 7.3's discipline is most useful as a conformance checklist, and it maps entirely onto canonical structural-exclusion and dark-surface findings.

7. **Cross-root equivalent control.** A path bypasses Control A (Root A) but necessarily crosses Control B (Root B). The equivalence test governs: B is accountability-equivalent only on all eight dimensions, critically including accountability termination (B's cut must terminate at a bonded root under the ratified cluster-3 rules). Similar policy, common vendor, same output label, affiliation, or intended similarity are explicitly insufficient. Correctly defined; ties to cluster-3.

8. **Distributed controls.** No single control is non-bypassable, but every path crosses some member of set C = {C1, C2, C3}. The frozen "control or accountability-equivalent control" language does *not* cleanly represent this: it is written for one control plus equivalents, not a set where different paths cross different members. This is a genuine wording gap. The successor should state that the enforcement object may be a *control set*, and non-bypassability holds when every capable path crosses at least one qualifying member. Also tested: several individually insufficient controls composing into qualifying enforcement, this needs the composition to be evidenced (each member's cut is qualifying for the paths it covers, and the members' coverage unions to all capable paths), which is the same coverage-of-set shape flagged in the cluster-6 65.7/65.9 work. Recommend the successor carry the control-set formulation and a coverage-union finding.

9. **Structurally incapable alternate path.** An alternate interface that cannot reach the target, carry the authority, or produce the consequence class does not defeat non-bypassability. This is canonical structural exclusion (line 73) applied to the bypass path: the incapable path is excluded from the candidate-path set, so it is not an uncut path. 7.3 must consume structural exclusion here, not re-derive it. Confirms derivability.

10. **Latent platform capability.** Bare imaginability must not create unresolvedness. The threshold, tested: an *evidence-compatible bypass path* requires bounded evidence identifying a route with capacity; a *bounded bypass dark surface* blocks only where independently supported evidence identifies a bounded unexamined route/interface/capability capable of the consequence class; *unbounded hypothetical possibility* does not create unresolvedness. This is exactly the 8.5 class-discovery-bound discipline and the line-335 "bounded, disclosed" dark-surface rule, applied to bypass paths. Same rule, different surface; not new architecture.

11. **Mixed open-weight/proprietary.** Architecture A (planner → proprietary control → executor, with executor independently reachable by direct tool invocation): the proprietary control is *not* non-bypassable, because the direct-invocation path reaches the executor uncut. This is the important result, a proprietary safety control is bypassable exactly when the executor it guards is independently reachable, which per-path evaluation catches immediately. Architecture B (primary through control A, fallback through local control B): A is bypassable, but the broader control *set* {A, B} may be bypass-complete if B is accountability-equivalent on the fallback path, which is case 8's control-set formulation. Confirms both the derivability finding and the control-set wording gap.

12. **Non-AI substrate.** Cloud deployment control with a direct administrative API: the admin API is a privileged bypass path (case 2); non-bypassability of the deployment control fails if the API reaches the same Actuation uncut. OT controller with manual maintenance override: the override is a bypass path requiring equivalence analysis (case 3). Financial emergency disbursement: case 3. Institutional alternate signing authority: case 7 cross-root equivalence. All instantiate on canonical machinery without AI-specific wording, confirming substrate neutrality and confirming 7.3's content is substrate-neutral conformance vocabulary over canonical findings.

All twelve resolve. None requires architecture beyond canonical per-path evaluation, structural exclusion, dark-surface capacity, and the equivalence definition. Cases 8 and 11-B expose one wording gap (control set vs single control). No case shows a false accountability result becoming provable in 7.3's absence.

## Criterion findings

**4.1 Provenance and exact identity:** established. Frozen from r12.1 sections 83-86 at 666e744e.

**4.2 Gap necessity:** the accountability result has no gap; canonical per-path plus dark-surface produces it. The gap is at the conformance/assurance level: v0.2 has no vocabulary for the positive claim "this named control (or control set) is the mandatory chokepoint for this consequence." That gap is real but is not a core-invariant gap.

**4.3 Exact-claim sufficiency:** the proposition is clean except for the single-control-vs-control-set wording (cases 8, 11-B). "Non-bypassable" should be marked a conformance predicate, not an accountability invariant, to prevent the reading that it adds a new exit condition.

**4.4 Non-redundancy:** at the accountability level, redundant with line 55 per-path exit and line 335 dark surface. At the conformance level, non-redundant: no canonical conformance vocabulary exists. Distinct from 7.2 (which path vs whether crossing was valid, case 5) and from record-action exactness (event proof vs enforcement completeness).

**4.5 Scope classification:** the accountability content is derivative of canonical per-path and dark-surface findings. The distinctive content is a **conformance/assurance claim with a run-level bypass-surface record** that reuses canonical findings. Not core normative architecture, not a new invariant.

**4.6 Cross-substrate treatment:** passes (case 12); the conformance vocabulary is substrate-neutral.

**4.7 Operational findings:** the assigned bypass-completeness finding structure (path set bounded/unbounded/unresolved; per-path Actuation-reach, consequence-capable, required-control-participation, accountability-equivalent-control; bypass capacity; actual bypass use; final non-bypassability) is admission-quality *as a conformance record*. Every field maps to a canonical finding it reuses; the record adds organization, not new findings. Recommend adding the control-set coverage-union finding (case 8).

**4.8 Evidence and dark surfaces:** the bypass dark surface is the canonical residual dark surface (line 335) scoped to alternate paths; the latent-capability threshold (case 10) is the canonical bounded-disclosed rule plus the 8.5 discovery bound. No new dark-surface architecture.

**4.9 Adversarial pressure:** twelve of twelve resolve on canonical machinery plus the equivalence definition; cases 8 and 11-B expose the control-set wording gap; no case produces a false accountability result in 7.3's absence.

**4.10 Interaction consistency:** consistent with line 55 (per-path exit), line 335 (dark surface), 7.2 (validity, cleanly dissociated in case 5), cluster-3 (accountability termination in the equivalence definition), 65.5 guard (no label-based equivalence), 65.7/65.9 (coverage-of-set shape in the control-set case), and 8.5 (discovery bound in case 10). Dense and consistent, which is expected for a candidate that reuses canonical findings.

**4.11 Scope-authority ownership:** investigative-frame authority selects the consequence, Actuation resolution, asserted control, path boundary, interfaces, alternate-route families, capability classes, and temporal interval; it may select the claim and resolution but cannot define a bypass path out of existence or suppress an evidence-compatible alternate representation (assignment requirement, and consistent with the ratified Section 92). Where two admissible frame resolutions produce different non-bypassability findings, the fork is preserved unless the result is invariant. No scope expansion by the candidate itself.

**4.12 Open questions resolved or retained:** resolves register question 10 for 7.3 (it is not necessary core architecture; it is conformance). Resolves question 6 (accountability-equivalent controls across roots: yes, under the eight-dimension definition including accountability termination). Retains the control-set composition question as a successor drafting item.

## Disposition (exactly one for frozen 7.3)

**Frozen 7.3: Conformance or assurance claim with record.** The accountability result is canonical (per-path exit plus dark-surface capacity); frozen 7.3 performs no independent core architectural work; its distinctive content is a conformance/assurance claim that a named control or control set is the mandatory enforcement chokepoint for a selected consequence, supported by the run-level bypass-surface record that reuses canonical findings.

**Successor (separately classified): Bypass-completeness conformance record and accountability-equivalent-control test, core operational apparatus for the conformance layer.** The successor is not a new invariant. It is the operational apparatus (the bypass-surface record with the control-set coverage-union finding, plus the eight-dimension equivalence test) that a deployer or investigator uses to make and check the non-bypassability conformance claim. It is core operational apparatus in the same sense 7.1's successor is: consumed by conformance/assurance claims and by the investigative frame, reusing but organizing canonical findings. Required successor edits: (1) state the enforcement object as a control *or control set*, with non-bypassability holding when every capable path crosses a qualifying member and the members' coverage unions to all capable paths; (2) mark "non-bypassable" a conformance predicate, not an accountability invariant; (3) carry the eight-dimension accountability-equivalence definition; (4) carry the latent-capability threshold (evidence-compatible path / bounded dark surface / unbounded hypothetical) explicitly.

```text
candidate closure record:
  candidate identifier: 7.3 bypass-complete control claim
  exact source state: r12.1 final 666e744e, sections 83-86
  primary-question finding: accountability result fully produced by canonical v0.2 (line 55 per-path exit + line 335 dark-surface capacity); frozen 7.3 adds no independent core accountability work
  what becomes falsely provable if absent: nothing at accountability level; an unresolved or capacity-present bypass path already blocks exit by burden under canonical rules
  distinctive content: conformance/assurance claim that a named control or control set is the mandatory chokepoint; supported by a run-level bypass-surface record reusing canonical path, capacity, and dark-surface findings
  frozen disposition: Conformance or assurance claim with record
  successor: Bypass-completeness conformance record + accountability-equivalent-control test; core operational apparatus for the conformance layer (NOT a new invariant)
  successor required edits: control-set formulation with coverage-union finding (cases 8, 11-B); mark non-bypassable a conformance predicate; carry eight-dimension equivalence definition; carry latent-capability threshold
  equivalence definition: eight dimensions (authority-bearing responsibility, protective scope, refusal/modification capacity, proposal-binding, validity continuity, Actuation reach, evidence burden, accountability termination); claim-relative; no label-based equivalence
  population coverage: explicitly NOT imported; all findings incident-level
  adversarial result: 12 of 12 resolve on canonical machinery + equivalence definition; cases 8, 11-B expose the control-set wording gap
  Larry disposition: pending
  final state: pending reviewer and author disposition
```

## Rater note

This time the evaluator reached the derivative/conformance finding directly rather than recommending core, which is the 7.1 lesson applied. The correlation risk here is the opposite of 7.1's: having just been overturned for over-claiming core, I may now be *over-correcting* toward derivative to avoid a second overturn, and a decorrelated reviewer should test whether I have wrongly derived away genuine core content. The specific point to check: I claim "non-bypassability is the per-path exit rule applied to accountability, therefore no core gap." A reviewer should test whether there is any consequence for which a control can be non-bypassable in the conformance sense while the per-path accountability result diverges, i.e., whether the two can come apart such that 7.3 does independent accountability work after all. I do not believe they diverge, because both quantify over the same evidence-compatible capable-path set, but that identity of quantification is the load-bearing claim and is exactly what an independent reader holding the canonical text should verify against lines 55 and 335. The second check: whether "conformance apparatus" under-classifies the successor, if bypass-completeness is consumed by a *propagation cut* (not only by an assurance claim), it would be core operational, not conformance. I classified it conformance because the per-path cut already handles the accountability cut without a named-control notion, but a reviewer who finds a cut that *requires* the named-control chokepoint concept would move the successor from conformance to core operational.
