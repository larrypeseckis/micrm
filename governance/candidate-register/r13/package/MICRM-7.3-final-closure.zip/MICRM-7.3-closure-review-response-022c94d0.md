# Reviewer response: Candidate 7.3, bypass-complete control claim

*Prepared 2026-07-20 (America/Denver). Reviewer: OpenAI GPT-5.6 Thinking, decorrelated reviewer. Evaluated artifact: `MICRM-7.3-bypass-complete-closure-evaluation-e9229b2e.md`, SHA-256 `e9229b2e7cafa918f094c11ad6d8839f56d9482caba2b6349eacbbe2a3539b77`. Frozen candidate source: register r12.1 final, SHA-256 `666e744e9e25795330b72ee3ef037f3884695586d7433bf444d66533fcc1a528`, Sections 83 through 86. Canonical base: MICRM-v0.2, SHA-256 `4180eaefa0369811262b805d189b3c572c8305d107bed6b84dd12c685650b0e2`. This response is reviewer input only. It does not modify the register, admit a candidate, or change canonical MICRM-v0.2.*

## Package and exact-byte verification

The returned evaluator package is intact.

```text
outer transport wrapper:
  3c420676edc0374d2a57aa8a1ed3dc5db655ca901ff4958def631457464abbfe

inner package:
  ce430edd4243dc9f67a3f33031df4b927068dc99a63567d21b0012be3564b54c

evaluation:
  e9229b2e7cafa918f094c11ad6d8839f56d9482caba2b6349eacbbe2a3539b77

verification record:
  c6b2c6d071fcf7a53a30e351c1a28d82a9579bf96d8ba65ea6f634e4ff8529c8

manifest:
  485bf763301c451e7c8dba15fbb9ced456792ddb928991b5c4bf5833cdccd53b

detached receipt:
  9d894fc7a0edaa63541fb6735e51e834af4d6f7a805886948d3f2631c6e8c1ed
```

The outer wrapper contains five files. The inner archive contains three entries. The manifest lists the evaluation and verification record, excludes itself, and passes two of two. The loose evaluation, verification record, and manifest are byte-identical to the inner copies. The standing builder passes its sixth production use.

## Review result

The evaluator's final classification largely survives:

> **Frozen Candidate 7.3 belongs in the conformance or assurance layer, with a bypass-surface record. It is not a new MICRM accountability invariant.**

The load-bearing derivability rationale does not survive as written.

The evaluator states that canonical per-path accountability and non-bypassability quantify over the same capable-path set and therefore cannot diverge. They do diverge. Canonical v0.2 evaluates ancestor paths in the actual incident run graph. Candidate 7.3 evaluates the counterfactual or architectural set of evidence-compatible paths capable of reaching the relevant Actuation, including routes independently established as unused in the incident.

That distinction preserves the evaluator's classification, but for a different reason:

- canonical v0.2 already produces the incident accountability result;
- Candidate 7.3 adds a distinct positive conformance claim about architectural enforcement coverage;
- and an unused capable bypass can defeat that conformance claim without defeating an otherwise established incident-specific accountability exit.

## 1. The two path universes are not identical

Canonical v0.2 defines an ancestor path as a directed path in the run graph from a traversal under a bonded root to the selected consequence.

Its second invariant then:

1. identifies candidate roots with ancestor paths to the selected consequence;
2. evaluates every path from each candidate root;
3. allows exit only where every such path contains a qualifying cut or structural exclusion;
4. and treats an unresolved incident path as blocking exit without proving contribution.

Those are incident-graph mechanics.

Frozen 7.3 instead asks whether every evidence-compatible path capable of producing the relevant Actuation must cross the named control or an accountability-equivalent control. That is a scoped architectural or counterfactual path claim. A route can be:

- capable of reaching the Actuation;
- independently established as unused during the incident;
- and therefore relevant to non-bypassability while not being an ancestor path in the selected incident run.

The evaluator's rater note correctly identified this as the point to attack. The identity-of-quantification claim fails.

## 2. Case 2(b) is incorrect

The evaluation states:

> Where a privileged route was available but independently shown unused, the accountability exit still fails because bypass capacity is present even if unused.

That is not canonical v0.2's incident result.

Consider:

```text
Actual incident path:
  upstream handoff -> Gate G -> Actuation

Alternate administrative route:
  capable of reaching the same Actuation
  independently established as unused during the incident
```

Assume the actual path satisfies every qualifying-cut condition and the evidence excludes use of the administrative route.

The findings are:

```text
Named-control non-bypassability:
  FAILED
  G was not a mandatory architectural chokepoint

Actual bypass use:
  EXCLUDED

Incident ancestor path through administrative route:
  ABSENT

Root exit on the actual incident graph:
  may still be established, subject to every other canonical condition
```

The unused route is not converted into an incident ancestor path solely because it had latent capacity.

This is the clean divergence the evaluator said it could not find:

```text
A control may be bypassable in the conformance sense
while the incident-specific MICRM accountability result
is fully resolved on the paths actually present.
```

That divergence confirms that 7.3 is not a restatement of the second invariant. It is a different claim class.

## 3. The dark-surface rule is incident-relative, not a global attack-surface rule

Canonical Section 7 blocks exit where a residual dark surface relevant to the alleged contribution class has present or unresolved capacity.

It does not say that every known but unused capable interface anywhere in the architecture blocks every incident exit.

The dark-surface test remains tied to:

- the selected consequence;
- the alleged contribution class;
- the incident graph;
- the candidate cut or exclusion;
- and the bounded uncertainty that must be resolved for that claim.

Where use of a capable alternate interface is independently excluded, that interface is not residual dark surface for the incident-use question. It can still defeat a positive non-bypassability assurance claim because that claim concerns architectural capacity, not incident use.

Treating any unused capable route as automatically blocking accountability exit would silently change MICRM from incident-relative structural accountability into a requirement that the deployed system have no bypass-capable architecture. Canonical v0.2 does not make that claim.

## 4. Correct relationship between canonical accountability and 7.3

The correct relationship is:

```text
Canonical per-path accountability:
  Which paths existed or remain unresolved in the selected incident,
  and did the root establish a cut or exclusion on every such path?

7.3 non-bypassability conformance:
  Across the bounded capable-path universe for the selected claim,
  must every route cross the asserted control or a qualifying alternate control?
```

They reuse many of the same evidence objects:

- interface identity;
- path reach;
- structural capacity;
- control participation;
- dark-surface bounds;
- and independently supported exclusions.

They do not produce the same finding.

This means the protocol's required gap question has a split answer:

```text
What becomes falsely provable at the accountability level if 7.3 is absent?
  Nothing. Canonical incident path mechanics remain sufficient.

What claim cannot be stated and checked cleanly if 7.3 is absent?
  The positive conformance claim that a named control is a mandatory
  enforcement chokepoint across the bounded capable-path universe.
```

## 5. Frozen 7.3 classification

The frozen proposition is properly classified as a **conformance or assurance claim with record**.

Its first sentence is not an additional root-exit condition. It defines the evidentiary burden for saying that a named control is non-bypassable.

Its final sentence correctly separates:

- unresolved bypass capacity, which blocks the universal control claim;
- from actual bypass use, which is not proven by that unresolved capacity.

The evaluator's classification is therefore accepted. The statement that frozen 7.3 is "fully produced" by canonical accountability mechanics is rejected.

## 6. Supporting apparatus is not MICRM core operational apparatus

The evaluator separately classifies the bypass-surface record and accountability-equivalent-control test as:

> core operational apparatus for the conformance layer

That classification should be narrowed.

The 7.1 successor was placed in the operational core because proposal-to-Actuation correspondence is consumed directly by core Gate governance, propagation-cut, and accountability-exit findings.

The 7.3 bypass-surface record is different. Its distinctive purpose is to support the positive conformance statement that a named control or control set is architecturally non-bypassable. Canonical accountability can resolve without that positive statement, as the unused-bypass example demonstrates.

Recommended classification:

> **Integration-ready conformance or assurance apparatus, not MICRM core operational apparatus.**

The record may reuse or supply evidence to incident-level path analysis. That evidentiary reuse does not move its conformance predicate into the core.

## 7. Named control and control-set claims must be separated

The evaluator treats cases 8 and 11-B as a defect in frozen 7.3's singular-control wording.

The narrower finding is preferable.

Frozen 7.3 asks whether one named control is non-bypassable. In a distributed architecture where different paths cross different non-equivalent controls, the truthful result may be:

```text
Control A:
  bypassable

Control B:
  bypassable

Control set {A, B}:
  bypass-complete
```

That does not make the named-control proposition false or incomplete. It shows that a separate set-level conformance object is useful.

Do not silently broaden "a control" into "a control or control set" inside the frozen proposition. Register a separate or explicitly generalized conformance formulation:

> **Bypass-complete enforcement set:** A defined control set is bypass-complete for a selected conformance claim only where independently supported evidence establishes that every path in the bounded capable-path universe crosses at least one qualifying set member, and that the members' verified coverage union includes every such path.

The set-level claim must also resolve:

- whether members are alternatives or compose on one path;
- whether each member independently qualifies for the path it covers;
- whether coverage union is complete;
- and whether uncovered, overlapping, or unresolved path classes remain.

## 8. Accountability-equivalent control requires a narrower definition

The evaluator's eight dimensions are useful, but the phrase must not imply that two controls under different bonded roots become the same root or carry identical terminal accountability.

A better formulation is:

> A control qualifies as an accountability-equivalent alternate-path control for a selected non-bypassability claim only where independently supported evidence establishes that, on the path it covers, the control supplies the authority, protective scope, real refusal or modification capacity, proposal-binding treatment, validity continuity, Actuation reach, evidence support, and accountability closure required by that selected claim.

Important consequences:

- implementation identity is not required;
- terminal-principal identity is not automatically required;
- each root remains separately qualified and separately represented;
- equivalence does not merge roots;
- and label, vendor, affiliation, or intended purpose does not establish equivalence.

For a heterogeneous control set, "qualifying set member" is cleaner than forcing every member to be equivalent to one privileged reference control.

## 9. Corrected operational findings

The bypass-surface record must preserve both universes explicitly.

```text
bypass-completeness conformance record:
  selected conformance claim:
  selected consequence class:
  relevant Actuation definition:
  asserted control:
  asserted control set, if separately evaluated:

  investigative frame:
    selecting authority and authority source:
    temporal interval:
    interface boundary:
    route families included:
    route families excluded and grounds:
    capability threshold:
    residual route-discovery dark surface:

  capable-path universe:
    path-family identifier:
    evidence compatibility:
    Actuation reach:
      established / excluded / unresolved
    consequence capacity:
      established / excluded / unresolved

  incident-use relation, where an incident is selected:
    used in incident:
      established / excluded / unresolved / not evaluated
    ancestor-path status:
      established / absent / unresolved / not applicable

  control coverage:
    required-control participation:
      established / absent / unresolved
    qualifying alternate-path control:
      established / failed / unresolved / not applicable
    qualifying control-set member:
      established / failed / unresolved / not applicable

  final named-control non-bypassability:
    established / failed / unresolved

  final enforcement-set bypass completeness:
    established / failed / unresolved / not evaluated

  evidence sources:
  independent corroboration:
  custody and modification control:
  residual dark surface:
```

This prevents a capable but excluded-as-unused route from being misclassified as an incident ancestor path.

## 10. Criterion findings

```text
4.1 Provenance and exact identity:
  PASS

4.2 Gap necessity:
  SPLIT
  no new incident-accountability rule is needed
  a distinct positive conformance claim is needed

4.3 Exact-claim sufficiency:
  PASS for the named-control conformance proposition
  supporting definitions and path-universe bounds are required
  a control-set claim must be stated separately

4.4 Non-redundancy:
  DERIVATIVE if read as an accountability-exit rule
  NON-REDUNDANT as a positive conformance or assurance claim

4.5 Scope classification:
  conformance or assurance layer

4.6 Cross-substrate treatment:
  PASS

4.7 Operational findings:
  REPAIR REQUIRED
  separate capable-path universe from incident ancestor paths
  separate named-control from control-set findings

4.8 Evidence and dark surfaces:
  REPAIR REQUIRED
  correct the case 2(b) global-capacity reading
  retain claim-relative bounded dark surfaces

4.9 Adversarial pressure:
  PARTIAL
  eleven cases support the classification
  case 2(b) produces an incorrect accountability result
  cases 8 and 11-B support a separate set-level claim

4.10 Interaction consistency:
  PASS after the two-universe correction
  7.2 remains validity continuity
  7.3 remains architectural path coverage

4.11 Scope-authority ownership:
  PASS
  investigative-frame authority cannot suppress an
  evidence-compatible capable route or invent an incident path

4.12 Open questions:
  frozen 7.3 classified as conformance
  set-level bypass completeness remains a separate drafting item
```

## Reviewer disposition

### Frozen Candidate 7.3

> **Conformance or assurance claim with record.**

The evaluator's final frozen-candidate classification is accepted.

The rationale is corrected: 7.3 is not fully derived from canonical incident per-path mechanics because it quantifies over a different capable-path universe. It remains outside the accountability core because that distinct universe supports a conformance claim, not an additional incident root-exit rule.

### Supporting record and equivalence test

> **Integration-ready conformance or assurance apparatus. Not MICRM core operational apparatus.**

### Control-set extension

> **Separate developed conformance candidate. Not resolved by frozen 7.3.**

```text
candidate closure record:
  candidate identifier:
    7.3 bypass-complete control claim

  exact source state:
    r12.1 final
    SHA-256 666e744e9e25795330b72ee3ef037f3884695586d7433bf444d66533fcc1a528
    Sections 83 through 86

  evaluator artifact:
    e9229b2e7cafa918f094c11ad6d8839f56d9482caba2b6349eacbbe2a3539b77

  evaluator disposition:
    Conformance or assurance claim with record

  reviewer disposition:
    Conformance or assurance claim with record

  evaluator rationale retained:
    no new incident-accountability invariant is required
    actual bypass use remains separate from bypass capacity

  evaluator rationale corrected:
    canonical ancestor paths and conformance-capable paths are not
    the same quantified set
    an independently excluded-as-unused bypass defeats non-bypassability
    but does not automatically block incident-specific root exit
    dark-surface capacity remains incident-relative and claim-relative

  supporting apparatus:
    bypass-surface record and qualifying alternate-path-control test

  supporting-apparatus classification:
    integration-ready conformance or assurance apparatus
    not MICRM core operational apparatus

  separate extension:
    bypass-complete enforcement-set conformance claim
    coverage-union and member-qualification findings required

  Larry disposition:
    pending

  final state:
    pending author disposition
```

## Rater note

The evaluator correctly resisted over-admission after 7.1, but over-derived 7.3 by treating an architectural capable-path universe as identical to the actual incident ancestor-path set.

The author should rule separately on:

1. frozen 7.3 as a conformance or assurance claim with record;
2. the supporting bypass-surface apparatus as conformance rather than MICRM core operational apparatus;
3. whether the control-set extension enters r13 as a separately registered conformance candidate or remains future profile work.

No register bytes should change before the author disposition.
